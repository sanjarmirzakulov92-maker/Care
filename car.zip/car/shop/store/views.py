from importlib.resources import contents

from django.shortcuts import render, redirect

from .forms import ContactForm
from .models import *
from django.views.generic import ListView, DetailView
from .models import Contact
from django.db.models import Q



class ProductList(ListView):
    model = Product
    context_object_name = 'categories'
    extra_context = {
        'title': 'Store Shop (Home)',
    }
    template_name = 'store/product_list.html'

    def get_queryset(self):
        categories = Category.objects.filter(parent=None)
        return categories


def contact_view(request):
    context = {
        'title': 'Register',
        'contact_form': ContactForm()
    }

    return render(request, 'store/contact_form.html', context)


def search_view(request):
    words = request.GET.get('q', '')
    articles = Product.objects.all()

    if words:
        articles = articles.filter(
            Q(title__icontains=words) | Q(description__icontains=words) | Q(price__icontains=words)
        )

    context = {
        'categories': articles,
        'query': words,
    }
    return render(request, 'store/product_list.html', context)
