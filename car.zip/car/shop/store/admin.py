from django.contrib import admin
from .models import *
from django.utils.safestring import mark_safe

class GalleryInline(admin.TabularInline):
    fk_name = 'product'
    model = Gallery
    extra = 1


@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ('title','parent')
    prepopulated_fields = {'slug':('title',)}


@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    list_display = ('pk', 'title', 'category','price', 'color', 'get_photo')
    list_filter = ('price', 'color')
    list_display_links = ('title',)
    list_filter = ('title', 'price')
    prepopulated_fields = {'slug':('title',)}
    inlines = [GalleryInline]


    def get_photo(self, obj):
        if obj.images:
            try:
                return mark_safe(f"<img src='{obj.images.all()[0].image.url}' width='75'>")
            except:
                return ""
        else:
            return ""



@admin.register(Contact)
class ContactAdmin(admin.ModelAdmin):
    list_display = ('name', 'phone', 'email', 'created_at')
    search_fields = ('name', 'phone', 'email')

admin.site.register(Gallery)

