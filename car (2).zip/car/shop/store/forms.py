from django import forms
from django.contrib.auth.forms import UserCreationForm
from .models import Contact


class ContactForm(forms.ModelForm):
    name = forms.CharField(widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'Name'
        }))
    phone = forms.CharField(widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'Phone Number'
        }))
    email = forms.EmailField(widget=forms.EmailInput(attrs={
            'class': 'form-control',
            'placeholder': 'Email'
        }))
    message = forms.CharField(widget=forms.Textarea(attrs={
            'class': 'message-bt',
            'placeholder': 'Message',
            'rows': 5
        }))

    class Meta:
        model = Contact
        fields = ['name', 'phone', 'email', 'message']









