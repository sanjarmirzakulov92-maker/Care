from django.urls import path
from django.shortcuts import render
from .models import Contact
from .views import *


urlpatterns = [
    path('', ProductList.as_view(), name='product_list'),
    path('contact_form/', contact_view, name='contact_form'),
    path('search/', search_view, name='search'),
    ]


#
# urlpatterns = [
#     path('', ProductList.as_view(), name='product-list'),
#     path("contact/", contact_view, name="contact"),
#     path("contact/success/", lambda request: render(request, "success.html"), name="contact_success"),
#
# ]
